(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_product_09fnm_q._.js","static/chunks/src_1um3xh0._.js","static/chunks/node_modules_1l4lkcl._.js","static/chunks/src_components_product_reviews_reviews_module_076a_5h.css"],
    source: "dynamic"
});
