(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/product/Lightbox.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_product_Lightbox_tsx_1wovss2._.js",
  "static/chunks/src_components_product_Lightbox_tsx_1--s8jd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/product/Lightbox.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/product/ProductDetailsAccordion.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_product_ProductDetailsAccordion_tsx_0d9flc3._.js",
  "static/chunks/src_components_product_ProductDetailsAccordion_tsx_1--s8jd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/product/ProductDetailsAccordion.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);