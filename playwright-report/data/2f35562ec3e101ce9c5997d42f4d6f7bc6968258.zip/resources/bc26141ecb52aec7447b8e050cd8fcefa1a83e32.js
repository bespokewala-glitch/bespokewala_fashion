(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/home/HeroSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/OptimizedImage.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function HeroSection({ campaigns = [] }) {
    _s();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const videoRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fallbackCampaigns = [
        {
            title: 'The Bridal Edit',
            subtitle: 'New Collection',
            videoUrl: '/clothures_video.mp4',
            linkUrl: '/products/couture/womens'
        },
        {
            title: 'High Jewellery',
            subtitle: 'Signature',
            videoUrl: '/jwellay_video.mp4',
            linkUrl: '/products/jewellery'
        },
        {
            title: 'Footwear',
            subtitle: 'Essentials',
            videoUrl: '/accessary_video.mp4',
            linkUrl: '/products/footwear'
        }
    ];
    const activeCampaigns = campaigns && campaigns.length > 0 ? campaigns : fallbackCampaigns;
    const currentCampaign = activeCampaigns[currentIndex];
    const handleVideoEnd = ()=>{
        setCurrentIndex((prev)=>(prev + 1) % activeCampaigns.length);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroSection.useEffect": ()=>{
            let timer;
            const isImg = activeCampaigns[currentIndex]?.videoUrl?.match(/\.(jpeg|jpg|gif|png|webp)$/i) != null;
            // Only auto-slide if we have more than 1 campaign
            if (activeCampaigns.length > 1) {
                if (isImg) {
                    timer = setTimeout({
                        "HeroSection.useEffect": ()=>{
                            setCurrentIndex({
                                "HeroSection.useEffect": (prev)=>(prev + 1) % activeCampaigns.length
                            }["HeroSection.useEffect"]);
                        }
                    }["HeroSection.useEffect"], 5000);
                }
            }
            // Always attempt to autoplay video when index changes
            if (!isImg && videoRef.current) {
                videoRef.current.play().catch({
                    "HeroSection.useEffect": (e)=>console.log("Autoplay prevented:", e)
                }["HeroSection.useEffect"]);
            }
            return ({
                "HeroSection.useEffect": ()=>{
                    if (timer) clearTimeout(timer);
                }
            })["HeroSection.useEffect"];
        }
    }["HeroSection.useEffect"], [
        currentIndex,
        activeCampaigns
    ]);
    const heroStyle = {
        position: 'relative',
        height: '100vh',
        width: '100%',
        overflow: 'hidden',
        display: 'flex',
        backgroundColor: '#000',
        touchAction: 'pan-y'
    };
    const arrowStyle = {
        position: 'absolute',
        top: '50%',
        transform: 'translateY(-50%)',
        zIndex: 2,
        background: 'transparent',
        border: 'none',
        color: '#fff',
        fontSize: '2rem',
        fontWeight: 300,
        cursor: 'pointer',
        padding: '2rem',
        opacity: 0.7,
        transition: 'opacity 0.3s ease'
    };
    const videoStyle = {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        zIndex: 0,
        transition: 'opacity 0.5s ease-in-out'
    };
    const overlayContentStyle = {
        position: 'absolute',
        zIndex: 1,
        textAlign: 'left',
        color: '#fff',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '1rem',
        textShadow: '0 2px 10px rgba(0,0,0,0.5)'
    };
    const subtitleStyle = {
        fontSize: '1rem',
        letterSpacing: '0.2em',
        textTransform: 'uppercase'
    };
    const titleStyle = {
        fontSize: '3.5rem',
        fontWeight: 300,
        letterSpacing: '0.15em',
        textTransform: 'uppercase',
        margin: 0
    };
    const primaryBtnStyle = {
        backgroundColor: '#fff',
        color: '#000',
        border: '1px solid #fff',
        padding: '0.8rem 1.5rem',
        textTransform: 'uppercase',
        letterSpacing: '0.1em',
        fontSize: '0.75rem',
        textDecoration: 'none',
        transition: 'all 0.3s ease',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: '160px'
    };
    const secondaryBtnStyle = {
        backgroundColor: 'transparent',
        color: '#fff',
        border: '1px solid #fff',
        padding: '0.8rem 1.5rem',
        textTransform: 'uppercase',
        letterSpacing: '0.1em',
        fontSize: '0.75rem',
        textDecoration: 'none',
        transition: 'all 0.3s ease',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: '160px'
    };
    const isImage = currentCampaign?.videoUrl?.match(/\.(jpeg|jpg|gif|png|webp)$/i) != null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        style: heroStyle,
        className: "mobile-hero-height hero-section",
        children: [
            isImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'relative',
                    width: '100%',
                    height: '100%'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: currentCampaign?.videoUrl || '',
                    alt: currentCampaign?.title ? `Bespokewala ${currentCampaign.title} collection` : 'Bespokewala luxury collection',
                    fill: true,
                    sizes: "100vw",
                    style: {
                        objectFit: 'cover'
                    },
                    priority: true,
                    variant: "large",
                    className: "hero-image"
                }, void 0, false, {
                    fileName: "[project]/src/components/home/HeroSection.tsx",
                    lineNumber: 160,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/home/HeroSection.tsx",
                lineNumber: 159,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                ref: videoRef,
                src: currentCampaign?.videoUrl,
                autoPlay: true,
                muted: true,
                loop: activeCampaigns.length <= 1,
                playsInline: true,
                onEnded: activeCampaigns.length > 1 ? handleVideoEnd : undefined,
                style: videoStyle,
                className: "hero-video"
            }, void 0, false, {
                fileName: "[project]/src/components/home/HeroSection.tsx",
                lineNumber: 172,
                columnNumber: 9
            }, this),
            activeCampaigns.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setCurrentIndex((prev)=>(prev - 1 + activeCampaigns.length) % activeCampaigns.length),
                        style: {
                            ...arrowStyle,
                            left: '1rem'
                        },
                        className: "hero-arrow-btn mobile-hide",
                        "aria-label": "Previous campaign",
                        onMouseEnter: (e)=>e.currentTarget.style.opacity = '1',
                        onMouseLeave: (e)=>e.currentTarget.style.opacity = '0.7',
                        children: "❮"
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 187,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setCurrentIndex((prev)=>(prev + 1) % activeCampaigns.length),
                        style: {
                            ...arrowStyle,
                            right: '1rem'
                        },
                        className: "hero-arrow-btn mobile-hide",
                        "aria-label": "Next campaign",
                        onMouseEnter: (e)=>e.currentTarget.style.opacity = '1',
                        onMouseLeave: (e)=>e.currentTarget.style.opacity = '0.7',
                        children: "❯"
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 197,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: overlayContentStyle,
                className: "hero-overlay mobile-p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                        children: `
          .hero-cta-group {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 1.5rem;
          }
          .hero-primary-btn:hover {
            background-color: #f0f0f0 !important;
          }
          .hero-secondary-btn:hover {
            background-color: rgba(255,255,255,0.1) !important;
          }
          @media (max-width: 768px) {
            .hero-cta-group {
              flex-direction: column;
              width: 100%;
              gap: 0.75rem;
            }
            .hero-primary-btn, .hero-secondary-btn {
              width: 100%;
            }
          }
        `
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 211,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: subtitleStyle,
                        className: "mobile-font-sm",
                        children: currentCampaign?.subtitle
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: titleStyle,
                        className: "mobile-hero-title",
                        children: currentCampaign?.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 236,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hero-cta-group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/contact",
                            className: "hero-secondary-btn",
                            style: secondaryBtnStyle,
                            children: "Book a Consultation"
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/HeroSection.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/HeroSection.tsx",
                        lineNumber: 238,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/HeroSection.tsx",
                lineNumber: 210,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/HeroSection.tsx",
        lineNumber: 157,
        columnNumber: 5
    }, this);
}
_s(HeroSection, "ZSfPZZfdACD3vAGUWGA9OfPFZH8=");
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/product/ProductCardWishlistButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/WishlistContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
// React.memo prevents this button from re-rendering when parent (ProductCard) re-renders
// due to unrelated state changes. On a listing page with 24 cards, adding one wishlist item
// without memo would re-render all 24 buttons — with memo, only the changed button updates.
const ProductCardWishlistButton = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c = _s(function ProductCardWishlistButton({ product }) {
    _s();
    const { addToWishlist, removeFromWishlist, isInWishlist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"])();
    const isWishlisted = isInWishlist(product.slug);
    const handleWishlistClick = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        if (isWishlisted) {
            removeFromWishlist(product.slug);
        } else {
            addToWishlist({
                slug: product.slug,
                name: product.name,
                price: product.price,
                image: product.primaryImage,
                productType: product.productType
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: handleWishlistClick,
        style: {
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'transparent',
            border: 'none',
            padding: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 10,
            transition: 'transform 0.2s ease'
        },
        "aria-label": isWishlisted ? 'Remove from wishlist' : 'Add to wishlist',
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            viewBox: "0 0 24 24",
            fill: isWishlisted ? '#fff' : 'none',
            stroke: "#fff",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"
            }, void 0, false, {
                fileName: "[project]/src/components/product/ProductCardWishlistButton.tsx",
                lineNumber: 69,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/product/ProductCardWishlistButton.tsx",
            lineNumber: 58,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/product/ProductCardWishlistButton.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}, "v3cOitCGxG5yM4kjIm55Qfv6IEQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"]
    ];
})), "v3cOitCGxG5yM4kjIm55Qfv6IEQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$WishlistContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWishlist"]
    ];
});
_c1 = ProductCardWishlistButton;
const __TURBOPACK__default__export__ = ProductCardWishlistButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "ProductCardWishlistButton$React.memo");
__turbopack_context__.k.register(_c1, "ProductCardWishlistButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/PremiumFeaturedCarousel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PremiumFeaturedCarousel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CurrencyContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/CurrencyContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/OptimizedImage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$ProductCardWishlistButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/product/ProductCardWishlistButton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function PremiumFeaturedCarousel({ products }) {
    _s();
    const { formatPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CurrencyContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCurrency"])();
    const carouselRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [showArrows, setShowArrows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PremiumFeaturedCarousel.useEffect": ()=>{
            const mql = window.matchMedia('(min-width: 768px)');
            setShowArrows(mql.matches);
            const handler = {
                "PremiumFeaturedCarousel.useEffect.handler": (e)=>setShowArrows(e.matches)
            }["PremiumFeaturedCarousel.useEffect.handler"];
            if (mql.addEventListener) {
                mql.addEventListener('change', handler);
            } else {
                mql.addListener(handler);
            }
            return ({
                "PremiumFeaturedCarousel.useEffect": ()=>{
                    if (mql.removeEventListener) {
                        mql.removeEventListener('change', handler);
                    } else {
                        mql.removeListener(handler);
                    }
                }
            })["PremiumFeaturedCarousel.useEffect"];
        }
    }["PremiumFeaturedCarousel.useEffect"], []);
    // Intersection Observer to detect the currently centered card
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PremiumFeaturedCarousel.useEffect": ()=>{
            const root = carouselRef.current;
            if (!root) return;
            const observer = new IntersectionObserver({
                "PremiumFeaturedCarousel.useEffect": (entries)=>{
                    entries.forEach({
                        "PremiumFeaturedCarousel.useEffect": (entry)=>{
                            if (entry.isIntersecting) {
                                const index = Number(entry.target.getAttribute('data-index'));
                                if (!isNaN(index)) {
                                    setActiveIndex(index);
                                }
                            }
                        }
                    }["PremiumFeaturedCarousel.useEffect"]);
                }
            }["PremiumFeaturedCarousel.useEffect"], {
                root: root,
                rootMargin: '0px -49% 0px -49%',
                threshold: 0
            });
            const cards = root.querySelectorAll('.unified-product-card');
            cards.forEach({
                "PremiumFeaturedCarousel.useEffect": (card)=>observer.observe(card)
            }["PremiumFeaturedCarousel.useEffect"]);
            return ({
                "PremiumFeaturedCarousel.useEffect": ()=>observer.disconnect()
            })["PremiumFeaturedCarousel.useEffect"];
        }
    }["PremiumFeaturedCarousel.useEffect"], [
        products
    ]);
    const scrollToIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PremiumFeaturedCarousel.useCallback[scrollToIndex]": (index)=>{
            if (carouselRef.current) {
                const cards = carouselRef.current.querySelectorAll('.unified-product-card');
                const card = cards[index];
                if (card) {
                    const container = carouselRef.current;
                    const containerCenter = container.clientWidth / 2;
                    const cardCenter = card.offsetLeft + card.clientWidth / 2;
                    container.scrollTo({
                        left: cardCenter - containerCenter,
                        behavior: 'smooth'
                    });
                }
            }
        }
    }["PremiumFeaturedCarousel.useCallback[scrollToIndex]"], []);
    const activeIndexRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(activeIndex);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PremiumFeaturedCarousel.useEffect": ()=>{
            activeIndexRef.current = activeIndex;
        }
    }["PremiumFeaturedCarousel.useEffect"], [
        activeIndex
    ]);
    // Auto-swipe functionality
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PremiumFeaturedCarousel.useEffect": ()=>{
            if (isHovered || !products || products.length <= 1) return;
            const interval = setInterval({
                "PremiumFeaturedCarousel.useEffect.interval": ()=>{
                    // Use the ref so we don't clear and restart the interval on every single scroll step
                    const nextIndex = (activeIndexRef.current + 1) % products.length;
                    scrollToIndex(nextIndex);
                }
            }["PremiumFeaturedCarousel.useEffect.interval"], 2500); // Normal, faster transition (2.5s)
            return ({
                "PremiumFeaturedCarousel.useEffect": ()=>clearInterval(interval)
            })["PremiumFeaturedCarousel.useEffect"];
        }
    }["PremiumFeaturedCarousel.useEffect"], [
        isHovered,
        products,
        scrollToIndex
    ]);
    const scrollLeft = ()=>{
        const prevIndex = (activeIndex - 1 + products.length) % products.length;
        scrollToIndex(prevIndex);
    };
    const scrollRight = ()=>{
        const nextIndex = (activeIndex + 1) % products.length;
        scrollToIndex(nextIndex);
    };
    if (!products || products.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "unified-carousel-wrapper",
        onMouseEnter: ()=>setIsHovered(true),
        onMouseLeave: ()=>setIsHovered(false),
        onTouchStart: ()=>setIsHovered(true),
        onTouchEnd: ()=>{
            // Short delay before resuming auto-swipe after touch
            setTimeout(()=>setIsHovered(false), 2000);
        },
        onTouchCancel: ()=>{
            setTimeout(()=>setIsHovered(false), 2000);
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        .unified-carousel-wrapper {
          position: relative;
          width: 100%;
          overflow: hidden;
          padding: 2rem 0;
        }
        @media (max-width: 768px) {
          .unified-carousel-wrapper {
            padding: 1rem 0 1rem 0;
          }
        }

        .unified-product-rail {
          display: flex;
          overflow-x: auto;
          scroll-snap-type: x mandatory;
          -webkit-overflow-scrolling: touch;
          scrollbar-width: none;
          -ms-overflow-style: none;
          gap: 1.5rem;
          /* Mobile padding to center the 75vw card */
          padding: 2rem calc(50vw - 37.5vw);
          scroll-behavior: smooth;
        }

        .unified-product-rail::-webkit-scrollbar {
          display: none;
        }

        .unified-product-card {
          scroll-snap-align: center;
          flex: 0 0 75vw;
          max-width: 320px;
          display: flex;
          flex-direction: column;
          text-align: left;
          position: relative;
          transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
          opacity: 0.75;
          transform: scale(0.95);
        }
        
        .unified-product-card.is-active {
          opacity: 1;
          transform: scale(1.02);
          z-index: 10;
        }

        .unified-product-image-wrap {
          width: 100%;
          aspect-ratio: 4 / 5;
          position: relative;
          border-radius: 2px;
          overflow: hidden;
          background-color: #F8F6F1;
          transition: transform 0.4s ease;
        }

        @media (min-width: 768px) {
          .unified-product-rail {
            /* Desktop padding to perfectly center a 300px card */
            padding: 2rem calc(50% - 150px);
            gap: 3rem;
          }
          .unified-product-card {
            flex: 0 0 300px;
            opacity: 0.65;
            transform: scale(0.92);
          }
          .unified-product-card.is-active {
            opacity: 1;
            transform: scale(1.05);
          }
          .unified-product-card:hover .unified-product-image-wrap {
            transform: scale(1.02);
          }
        }

        .unified-product-info {
          margin-top: 20px;
          text-align: center;
          padding: 0 10px;
        }

        .unified-product-title {
          font-size: 0.85rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #111;
          margin: 0 0 6px 0;
          line-height: 1.5;
          font-weight: 300;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .unified-product-price {
          font-size: 0.85rem;
          font-weight: 300;
          color: #777;
          margin: 0;
          letter-spacing: 0.05em;
        }

        .unified-nav-btn {
          position: absolute;
          /* Roughly center with the image part of the card (4/5 aspect ratio) */
          top: calc(2rem + 350px / 2); 
          transform: translateY(-50%);
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background-color: transparent;
          border: 1px solid rgba(0,0,0,0.1);
          cursor: pointer;
          z-index: 30;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #111;
          transition: all 0.3s ease;
          backdrop-filter: blur(4px);
        }
        
        .unified-nav-btn:hover {
          border-color: rgba(0,0,0,0.4);
          background-color: rgba(255,255,255,0.9);
        }

        .nav-left {
          left: 2rem;
        }

        .nav-right {
          right: 2rem;
        }

        .mobile-swipe-indicator {
          font-size: 10px;
          letter-spacing: 1.5px;
          color: #887a6d;
          text-transform: uppercase;
          margin-top: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        @media (min-width: 768px) {
          .mobile-swipe-indicator {
            display: none;
          }
          .unified-nav-btn {
            top: calc(2rem + 375px / 2); /* Desktop height adjustment */
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                lineNumber: 126,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "unified-product-rail",
                ref: carouselRef,
                children: products.map((product, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/products/${product.slug}`,
                        className: `unified-product-card ${index === activeIndex ? 'is-active' : ''}`,
                        "data-index": index,
                        prefetch: false,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "unified-product-image-wrap",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: product.images[0],
                                        alt: `Bespokewala ${product.name}`,
                                        fill: true,
                                        style: {
                                            objectFit: 'cover'
                                        },
                                        variant: "thumbnail",
                                        sizes: "(max-width: 768px) 80vw, 300px",
                                        loading: index < 4 ? 'eager' : 'lazy',
                                        priority: index < 2
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                        lineNumber: 298,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$ProductCardWishlistButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        product: {
                                            slug: product.slug,
                                            name: product.name,
                                            price: product.price,
                                            primaryImage: product.images[0]
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                        lineNumber: 308,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                lineNumber: 297,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "unified-product-info",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "unified-product-title",
                                        children: product.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                        lineNumber: 318,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "unified-product-price",
                                        children: formatPrice(product.price)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                        lineNumber: 319,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                lineNumber: 317,
                                columnNumber: 13
                            }, this)
                        ]
                    }, product._id, true, {
                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                        lineNumber: 290,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                lineNumber: 288,
                columnNumber: 7
            }, this),
            showArrows && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: scrollLeft,
                        "aria-label": "Previous featured product",
                        className: "unified-nav-btn nav-left",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "12",
                            height: "20",
                            viewBox: "0 0 14 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                points: "10 18 4 12 10 6"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                lineNumber: 333,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                            lineNumber: 332,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                        lineNumber: 327,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: scrollRight,
                        "aria-label": "Next featured product",
                        className: "unified-nav-btn nav-right",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "12",
                            height: "20",
                            viewBox: "0 0 14 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                points: "4 18 10 12 4 6"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                                lineNumber: 342,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                            lineNumber: 341,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                        lineNumber: 336,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            !showArrows && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mobile-swipe-indicator",
                children: [
                    "SWIPE TO EXPLORE ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "→"
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                        lineNumber: 350,
                        columnNumber: 28
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
                lineNumber: 349,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/PremiumFeaturedCarousel.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
_s(PremiumFeaturedCarousel, "CIZ99iCTqQU7WfKn4R4mBLFGoSM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CurrencyContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCurrency"]
    ];
});
_c = PremiumFeaturedCarousel;
var _c;
__turbopack_context__.k.register(_c, "PremiumFeaturedCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/SplitShowcase.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SplitShowcase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/OptimizedImage.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function SplitShowcase({ data }) {
    _s();
    const modelImage = data?.modelImage || "https://images.unsplash.com/photo-1549439602-43ebca2327af?auto=format&fit=crop&q=80";
    // Hardcoded default products matching the luxury jewelry aesthetic
    const defaultProducts = [
        {
            id: 1,
            image: "https://images.unsplash.com/photo-1605100804763-247f66126e28?auto=format&fit=crop&q=80",
            name: "Three Two Four Ring",
            price: "$12,000"
        },
        {
            id: 2,
            image: "https://images.unsplash.com/photo-1599643478514-4a4e09b52342?auto=format&fit=crop&q=80",
            name: "Drop Pendant",
            price: "$5,200"
        },
        {
            id: 3,
            image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80",
            name: "Diamond Earrings",
            price: "$4,800"
        },
        {
            id: 4,
            image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&q=80",
            name: "Diamond Bracelet",
            price: "$7,500"
        },
        {
            id: 5,
            image: "https://images.unsplash.com/photo-1596944924616-7b38e7cfac36?auto=format&fit=crop&q=80",
            name: "Ruby Ring",
            price: "$6,200"
        }
    ];
    const products = data?.products || defaultProducts;
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SplitShowcase.useEffect": ()=>{
            const timer = setInterval({
                "SplitShowcase.useEffect.timer": ()=>{
                    setCurrentIndex({
                        "SplitShowcase.useEffect.timer": (prev)=>(prev + 1) % products.length
                    }["SplitShowcase.useEffect.timer"]);
                }
            }["SplitShowcase.useEffect.timer"], 4000);
            return ({
                "SplitShowcase.useEffect": ()=>clearInterval(timer)
            })["SplitShowcase.useEffect"];
        }
    }["SplitShowcase.useEffect"], [
        products.length
    ]);
    const handleNext = ()=>setCurrentIndex((prev)=>(prev + 1) % products.length);
    const handlePrev = ()=>setCurrentIndex((prev)=>(prev - 1 + products.length) % products.length);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        style: {
            display: 'flex',
            width: '100%',
            minHeight: '80vh',
            backgroundColor: '#fff',
            flexWrap: 'wrap'
        },
        className: "mobile-flex-col mobile-min-h-auto split-showcase-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                dangerouslySetInnerHTML: {
                    __html: `
        @keyframes subtleFadeIn {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .slide-anim {
          animation: subtleFadeIn 0.8s ease forwards;
        }
      `
                }
            }, void 0, false, {
                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "split-showcase-image",
                style: {
                    flex: '1 1 50%',
                    minWidth: '300px',
                    minHeight: '400px',
                    position: 'relative'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: modelImage || '',
                    alt: "Bespokewala model showcasing luxury jewellery",
                    fill: true,
                    sizes: "(max-width: 767px) 100vw, 50vw",
                    style: {
                        objectFit: 'cover'
                    },
                    variant: "medium",
                    loading: "lazy"
                }, void 0, false, {
                    fileName: "[project]/src/components/home/SplitShowcase.tsx",
                    lineNumber: 78,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "split-showcase-content mobile-section-py mobile-px-container",
                style: {
                    flex: '1 1 50%',
                    minWidth: '300px',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '4rem 2rem 2rem 2rem',
                    textAlign: 'center',
                    backgroundColor: '#fff',
                    position: 'relative'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginBottom: '2rem'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                style: {
                                    fontSize: '0.75rem',
                                    letterSpacing: '0.15em',
                                    color: '#666',
                                    textTransform: 'uppercase',
                                    marginBottom: '0.5rem'
                                },
                                className: "mobile-label-clamp",
                                children: "Our Collection"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: '30px',
                                    height: '1px',
                                    backgroundColor: '#ccc',
                                    margin: '0 auto'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                lineNumber: 106,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: 'relative',
                            width: '100%',
                            maxWidth: '500px',
                            flex: 1,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: products[currentIndex].slug ? `/products/${products[currentIndex].slug}` : '#',
                                style: {
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    margin: '0 3rem',
                                    textDecoration: 'none',
                                    width: '100%'
                                },
                                "aria-label": `View ${products[currentIndex].name}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            position: 'relative',
                                            width: '100%',
                                            maxWidth: '300px',
                                            height: '300px',
                                            marginBottom: '1.5rem'
                                        },
                                        className: "mobile-slider-img",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: products[currentIndex].image || '',
                                            alt: products[currentIndex].name ? `Bespokewala ${products[currentIndex].name}` : 'Bespokewala luxury product',
                                            fill: true,
                                            sizes: "(max-width: 768px) 100vw, 50vw",
                                            style: {
                                                objectFit: 'contain'
                                            },
                                            variant: "thumbnail",
                                            loading: "lazy"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                            lineNumber: 114,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                        lineNumber: 113,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        style: {
                                            fontSize: '1.2rem',
                                            fontWeight: 400,
                                            color: '#333',
                                            marginBottom: '0.5rem',
                                            fontFamily: 'serif'
                                        },
                                        className: "mobile-h3-clamp",
                                        children: products[currentIndex].name
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        style: {
                                            fontSize: '1rem',
                                            color: '#888'
                                        },
                                        className: "mobile-body-clamp",
                                        children: products[currentIndex].price
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                        lineNumber: 125,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    gap: '10px',
                                    marginTop: '1.5rem'
                                },
                                className: "mobile-section-mt",
                                children: products.map((_, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setCurrentIndex(idx),
                                        "aria-label": `Go to slide ${idx + 1}`,
                                        style: {
                                            width: '6px',
                                            height: '6px',
                                            borderRadius: '50%',
                                            backgroundColor: idx === currentIndex ? '#333' : '#e0e0e0',
                                            cursor: 'pointer',
                                            transition: 'background-color 0.3s',
                                            border: 'none',
                                            padding: 0
                                        }
                                    }, idx, false, {
                                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                        lineNumber: 131,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/SplitShowcase.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/SplitShowcase.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/SplitShowcase.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, this);
}
_s(SplitShowcase, "tPjzCc9H5UuFdWNuAHYoD0K4UOk=");
_c = SplitShowcase;
var _c;
__turbopack_context__.k.register(_c, "SplitShowcase");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/CoutureProcess.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CoutureProcess
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function CoutureProcess({ data }) {
    _s();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Fallback data if none is provided via CMS
    const defaultSteps = [
        {
            title: "Design Consultation",
            description: "Discuss your vision, occasion, style preferences, and customization requirements with our design experts.",
            image: "https://images.unsplash.com/photo-1558769132-cb1fac0850f9?auto=format&fit=crop&q=80&w=800",
            enabled: true
        },
        {
            title: "Fabric & Craft Selection",
            description: "Select premium fabrics, embroidery techniques, embellishments, and handcrafted details for your couture piece.",
            image: "https://images.unsplash.com/photo-1555529771-835f59bfc50c?auto=format&fit=crop&q=80&w=800",
            enabled: true
        },
        {
            title: "Tailoring & Handcrafting",
            description: "Our skilled artisans carefully cut, stitch, and handcraft every detail to create a perfectly fitted masterpiece.",
            image: "https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?auto=format&fit=crop&q=80&w=800",
            enabled: true
        },
        {
            title: "Final Fitting & Delivery",
            description: "After a final quality check and fitting, your couture creation is beautifully packaged and delivered.",
            image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=800",
            enabled: true
        }
    ];
    const steps = data?.steps && Array.isArray(data.steps) && data.steps.length >= 4 ? data.steps.filter((s)=>s.enabled) : defaultSteps;
    if (steps.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        id: "couture-process",
        style: {
            backgroundColor: '#faf8f5',
            padding: '6rem 2rem'
        },
        className: "mobile-section-py mobile-px-container",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                maxWidth: '1400px',
                margin: '0 auto',
                textAlign: 'center'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    style: {
                        fontSize: '2.5rem',
                        fontWeight: 300,
                        letterSpacing: '0.1em',
                        marginBottom: '1rem',
                        textTransform: 'uppercase',
                        color: '#111'
                    },
                    className: "mobile-h2-clamp",
                    children: "The Couture Process"
                }, void 0, false, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: {
                        color: '#555',
                        maxWidth: '600px',
                        margin: '0 auto 4rem auto',
                        fontSize: '1rem',
                        lineHeight: '1.6'
                    },
                    className: "mobile-body-clamp mobile-mb-4",
                    children: "Experience the journey of creating your bespoke masterpiece, from the first sketch to the final fitting."
                }, void 0, false, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                    children: `
          .process-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 2rem;
          }
          .process-step-card {
            display: flex;
            flex-direction: column;
            text-align: left;
          }
          .process-image-wrapper {
            position: relative;
            width: 100%;
            padding-bottom: 125%; /* 4:5 aspect ratio */
            overflow: hidden;
            margin-bottom: 1.5rem;
            background-color: #eee;
          }
          .process-image-wrapper img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.7s ease;
          }
          .process-step-card:hover .process-image-wrapper img {
            transform: scale(1.05);
          }
          .process-step-number {
            font-size: 0.85rem;
            letter-spacing: 0.15em;
            color: #888;
            margin-bottom: 0.5rem;
            display: block;
          }
          .process-step-title {
            font-size: 1.2rem;
            font-weight: 400;
            color: #111;
            margin-bottom: 1rem;
            letter-spacing: 0.05em;
          }
          .process-step-desc {
            font-size: 0.9rem;
            color: #666;
            line-height: 1.6;
          }
          @media (max-width: 1024px) {
            .process-grid {
              grid-template-columns: repeat(2, 1fr);
              gap: 3rem 2rem;
            }
          }
          @media (max-width: 768px) {
            .process-grid {
              grid-template-columns: 1fr;
              gap: 2.5rem;
            }
            .process-image-wrapper {
              padding-bottom: 100%; /* 1:1 on mobile */
            }
            .process-btn-wrapper {
              margin-top: 2.5rem !important;
            }
            .process-step-card:not(:first-child) {
              display: none;
            }
            .process-grid.expanded .process-step-card {
              display: flex;
            }
            .expand-process-btn {
              display: flex !important;
            }
          }

          .expand-process-btn {
            display: none;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
            margin-top: 1.5rem;
            background: none;
            border: none;
            border-top: 1px solid #eaeaea;
            border-bottom: 1px solid #eaeaea;
            color: #111;
            font-size: 0.85rem;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            cursor: pointer;
            padding: 1rem;
          }
          .expand-process-btn svg {
            transition: transform 0.3s ease;
          }
          .expand-process-btn.expanded svg {
            transform: rotate(180deg);
          }
        `
                }, void 0, false, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `process-grid ${isExpanded ? 'expanded' : ''}`,
                    children: steps.map((step, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "process-step-card",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "process-image-wrapper",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: step.image || step.media || defaultSteps[index]?.image,
                                        alt: step.title,
                                        loading: "lazy"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                        lineNumber: 159,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                    lineNumber: 158,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "process-step-number",
                                            children: [
                                                "STEP 0",
                                                index + 1
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                            lineNumber: 162,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "process-step-title",
                                            children: step.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                            lineNumber: 163,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "process-step-desc",
                                            children: step.description
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                            lineNumber: 164,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                    lineNumber: 161,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/components/home/CoutureProcess.tsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 155,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: `expand-process-btn ${isExpanded ? 'expanded' : ''}`,
                    onClick: ()=>setIsExpanded(!isExpanded),
                    children: [
                        isExpanded ? 'Show Less' : 'Read Full Process',
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "14",
                            height: "14",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                points: "6 9 12 15 18 9"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/CoutureProcess.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/CoutureProcess.tsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "process-btn-wrapper",
                    style: {
                        marginTop: '5rem',
                        textAlign: 'center'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: "/contact",
                        className: "btn-primary",
                        style: {
                            display: 'inline-block',
                            padding: '1rem 2.5rem',
                            backgroundColor: '#1c1c1c',
                            color: '#fff',
                            textDecoration: 'none',
                            fontSize: '0.85rem',
                            letterSpacing: '0.15em',
                            textTransform: 'uppercase',
                            transition: 'background-color 0.3s ease'
                        },
                        onMouseOver: (e)=>e.currentTarget.style.backgroundColor = '#d2b48c',
                        onMouseOut: (e)=>e.currentTarget.style.backgroundColor = '#1c1c1c',
                        children: "Book a Consultation"
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/CoutureProcess.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/home/CoutureProcess.tsx",
                    lineNumber: 180,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/home/CoutureProcess.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/home/CoutureProcess.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(CoutureProcess, "FPNvbbHVlWWR4LKxxNntSxiIS38=");
_c = CoutureProcess;
var _c;
__turbopack_context__.k.register(_c, "CoutureProcess");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/LookbookCarousel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LookbookCarousel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/OptimizedImage.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function LookbookCarousel({ data }) {
    _s();
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const defaultMuses = [
        {
            name: 'Ranveer Singh',
            img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80'
        },
        {
            name: 'Alia Bhatt',
            img: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80'
        },
        {
            name: 'Shahrukh Khan',
            img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80'
        }
    ];
    const subtitle = data?.subtitle || "Where dreams are draped in couture and stars become muse.";
    const muses = data?.items && data.items.length > 0 ? data.items.map((i)=>({
            name: i.name || '',
            img: i.image || ''
        })) : defaultMuses;
    const scroll = (direction)=>{
        if (scrollRef.current) {
            const { scrollLeft, clientWidth } = scrollRef.current;
            const scrollTo = direction === 'left' ? scrollLeft - clientWidth / 2 : scrollLeft + clientWidth / 2;
            scrollRef.current.scrollTo({
                left: scrollTo,
                behavior: 'smooth'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "lookbook-carousel-section",
        style: {
            backgroundColor: '#fafafa',
            textAlign: 'center',
            position: 'relative'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        .lookbook-carousel-section {
          padding: 6rem 2rem 1rem;
        }
        .lookbook-subtitle {
          margin-bottom: 4rem;
        }
        @media (max-width: 768px) {
          .lookbook-carousel-section {
            padding: 1rem 1rem 0 1rem;
          }
          .lookbook-subtitle {
            margin-bottom: 2rem !important;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "lookbook-subtitle",
                style: {
                    color: '#666',
                    fontSize: '0.9rem',
                    fontStyle: 'italic'
                },
                children: subtitle
            }, void 0, false, {
                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>scroll('left'),
                style: {
                    position: 'absolute',
                    top: '50%',
                    left: '1rem',
                    transform: 'translateY(-50%)',
                    zIndex: 10,
                    background: 'rgba(255,255,255,0.7)',
                    border: 'none',
                    borderRadius: '50%',
                    width: '40px',
                    height: '40px',
                    cursor: 'pointer',
                    fontSize: '1.2rem',
                    boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
                },
                children: "❮"
            }, void 0, false, {
                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>scroll('right'),
                style: {
                    position: 'absolute',
                    top: '50%',
                    right: '1rem',
                    transform: 'translateY(-50%)',
                    zIndex: 10,
                    background: 'rgba(255,255,255,0.7)',
                    border: 'none',
                    borderRadius: '50%',
                    width: '40px',
                    height: '40px',
                    cursor: 'pointer',
                    fontSize: '1.2rem',
                    boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
                },
                children: "❯"
            }, void 0, false, {
                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: scrollRef,
                style: {
                    display: 'flex',
                    overflowX: 'auto',
                    scrollSnapType: 'x mandatory',
                    gap: '2rem',
                    paddingBottom: '2rem',
                    scrollbarWidth: 'none',
                    msOverflowStyle: 'none'
                },
                children: muses.map((muse, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            flex: '0 0 auto',
                            width: '300px',
                            scrollSnapAlign: 'start',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: '100%',
                                    height: '400px',
                                    borderRadius: '20px',
                                    overflow: 'hidden',
                                    marginBottom: '1.5rem',
                                    boxShadow: '0 10px 30px rgba(0,0,0,0.05)',
                                    position: 'relative'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: muse.img,
                                    alt: muse.name,
                                    fill: true,
                                    sizes: "(max-width: 768px) 100vw, 300px",
                                    style: {
                                        objectFit: 'cover'
                                    },
                                    variant: "medium"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                                lineNumber: 99,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: {
                                    fontSize: '1rem',
                                    letterSpacing: '0.1em',
                                    textTransform: 'uppercase',
                                    color: '#333',
                                    margin: 0
                                },
                                children: muse.name
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                                lineNumber: 117,
                                columnNumber: 13
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/home/LookbookCarousel.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/LookbookCarousel.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(LookbookCarousel, "rUl6RJdP9XfufN21BrtKqIOri0o=");
_c = LookbookCarousel;
var _c;
__turbopack_context__.k.register(_c, "LookbookCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/BrandStory.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BrandStory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/OptimizedImage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
"use client";
;
;
;
function BrandStory({ data }) {
    const subtitle = data?.subtitle || "Our Heritage";
    const title = data?.title || "Crafting Elegance,\nStitching Legacy.";
    const text1 = data?.text1 || "At Bespokewala, we believe true luxury lies in the details. Every piece we create is a testament to the rich heritage of Indian craftsmanship, blended seamlessly with contemporary silhouettes. From the intricate zari work to the delicate hand-embroidery, our artisans pour their heart into every stitch.";
    const text2 = data?.text2 || "Our bespoke philosophy ensures that every garment is more than just clothing; it is a personalized work of art, designed to celebrate your unique identity and the most special moments of your life.";
    const ctaText = data?.ctaText || "Discover Our Story";
    const ctaLink = data?.ctaLink || "/about";
    const image = data?.image || "https://images.unsplash.com/photo-1584308972271-204c35ce82c3?auto=format&fit=crop&q=80&w=1200";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "brand-story-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        .brand-story-section {
          padding: 3rem 4rem 8rem;
          background-color: #fcfcfc;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .brand-story-container {
          max-width: 1400px;
          width: 100%;
          display: flex;
          gap: 6rem;
          align-items: center;
        }
        .brand-story-image-wrapper {
          flex: 1;
          position: relative;
          height: 700px;
          border-radius: 4px;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0,0,0,0.08);
        }
        .brand-story-content {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2rem;
          padding-right: 2rem;
        }
        .brand-story-subtitle {
          font-size: 0.85rem;
          text-transform: uppercase;
          letter-spacing: 0.2em;
          color: #888;
          font-weight: 600;
        }
        .brand-story-title {
          font-size: 3rem;
          font-weight: 300;
          letter-spacing: 0.05em;
          color: #111;
          line-height: 1.2;
          white-space: pre-line;
        }
        .brand-story-text {
          font-size: 1.1rem;
          line-height: 1.8;
          color: #555;
          font-weight: 300;
        }
        .brand-story-cta {
          display: inline-block;
          margin-top: 1rem;
          padding: 1rem 2.5rem;
          background-color: transparent;
          color: #111;
          border: 1px solid #111;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          font-size: 0.85rem;
          text-decoration: none;
          transition: all 0.3s ease;
          align-self: flex-start;
        }
        .brand-story-cta:hover {
          background-color: #111;
          color: #fff;
        }
        @media (max-width: 1024px) {
          .brand-story-section {
            padding: 3rem 2rem 6rem;
          }
          .brand-story-container {
            flex-direction: column;
            gap: 4rem;
          }
          .brand-story-content {
            padding-right: 0;
            text-align: center;
            align-items: center;
          }
          .brand-story-image-wrapper {
            width: 100%;
            height: 500px;
            order: -1;
          }
          .brand-story-title {
            font-size: 2.5rem;
          }
        }
        @media (max-width: 768px) {
          .brand-story-section {
            padding: 2rem 1.5rem;
          }
          .brand-story-image-wrapper {
            height: 400px;
          }
          .brand-story-title {
            font-size: 2rem;
          }
          .brand-story-text {
            font-size: 1rem;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/home/BrandStory.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "brand-story-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "brand-story-content",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "brand-story-subtitle",
                                children: subtitle
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/BrandStory.tsx",
                                lineNumber: 127,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "brand-story-title",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/BrandStory.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "brand-story-text",
                                children: text1
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/BrandStory.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "brand-story-text",
                                children: text2
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/BrandStory.tsx",
                                lineNumber: 130,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: ctaLink,
                                className: "brand-story-cta",
                                children: ctaText
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/BrandStory.tsx",
                                lineNumber: 131,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/BrandStory.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "brand-story-image-wrapper",
                        children: image.match(/\.(mp4|webm|ogg)$/i) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                            src: image,
                            autoPlay: true,
                            loop: true,
                            muted: true,
                            playsInline: true,
                            style: {
                                width: '100%',
                                height: '100%',
                                objectFit: 'cover'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/BrandStory.tsx",
                            lineNumber: 138,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$OptimizedImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: image,
                            alt: "Craftsmanship and Heritage",
                            fill: true,
                            style: {
                                objectFit: 'cover'
                            },
                            sizes: "(max-width: 1024px) 100vw, 50vw",
                            priority: false
                        }, void 0, false, {
                            fileName: "[project]/src/components/home/BrandStory.tsx",
                            lineNumber: 147,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/BrandStory.tsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/BrandStory.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/BrandStory.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c = BrandStory;
var _c;
__turbopack_context__.k.register(_c, "BrandStory");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/TrustSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TrustSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function TrustSection() {
    _s();
    const scrollContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const handleScroll = ()=>{
        if (!scrollContainerRef.current) return;
        const scrollLeft = scrollContainerRef.current.scrollLeft;
        const container = scrollContainerRef.current;
        let closestIndex = 0;
        let minDiff = Infinity;
        Array.from(container.children).forEach((child, index)=>{
            const childCenter = child.offsetLeft + child.offsetWidth / 2;
            const containerCenter = scrollLeft + container.offsetWidth / 2;
            const diff = Math.abs(childCenter - containerCenter);
            if (diff < minDiff) {
                minDiff = diff;
                closestIndex = index;
            }
        });
        if (closestIndex !== activeIndex) {
            setActiveIndex(closestIndex);
        }
    };
    // Keep desktop styles mostly inline or in the generic classes
    // We'll reset mobile typography entirely in the media query.
    const titleStyle = {
        fontSize: '0.85rem',
        letterSpacing: '0.15em',
        textTransform: 'uppercase',
        fontWeight: 500,
        color: '#333',
        margin: 0
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "trust-container",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        /* Desktop styles (Default) */
        .trust-container {
          padding: 4rem 2rem;
          background-color: #fff;
          border-top: 1px solid #f0f0f0;
          border-bottom: 1px solid #f0f0f0;
          display: flex;
          justify-content: center;
        }
        .trust-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 3rem;
          width: 100%;
          max-width: 1200px;
          text-align: center;
        }
        .trust-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.75rem;
        }
        .trust-desc {
          font-size: 0.9rem;
          color: #777;
          font-style: italic;
          margin: 0;
          line-height: 1.4;
        }
        .trust-link {
          color: #c1a68d;
          text-decoration: none;
          font-size: 0.8rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-top: 0.25rem;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-weight: 500;
          transition: opacity 0.2s ease;
          min-height: 44px;
          min-width: 44px;
        }
        .trust-link:hover {
          opacity: 0.8;
        }
        .trust-link:hover .arrow-icon {
          transform: translateX(4px);
        }
        .arrow-icon {
          display: inline-block;
          margin-left: 4px;
          transition: transform 0.2s ease;
        }
        
        .trust-card-num {
          display: none; /* Hidden on desktop */
        }
        
        .mobile-header-wrapper,
        .mobile-indicator-wrapper {
          display: none;
        }

        /* Mobile specific styles */
        @media (max-width: 767px) {
          .trust-container {
            padding: 36px 0 0 0;
            display: block;
            border-top: none;
            border-bottom: none;
            background-color: #fff;
          }
          
          .mobile-header-wrapper {
            display: block;
            padding: 0 20px;
            margin-bottom: 30px;
            text-align: center;
          }
          .mobile-section-heading {
            font-size: 22px;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: 300;
            color: #111;
            margin: 0 0 8px 0;
          }
          .mobile-section-sub {
            font-size: 12px;
            color: #666;
            margin: 0;
            font-style: italic;
          }
          
          .trust-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px 16px;
            padding: 0 20px;
            text-align: left;
            margin-bottom: 30px;
          }
          
          .trust-item {
            align-items: flex-start;
            background-color: transparent;
            border: none;
            border-radius: 0;
            padding: 0;
            height: auto;
            gap: 0;
            justify-content: flex-start;
            max-width: 100%;
          }
          
          .trust-card-num {
            display: block;
            font-size: 9px;
            letter-spacing: 1.5px;
            color: #887a6d;
            margin-bottom: 12px;
          }

          .trust-item h3 {
            font-size: 13px !important;
            letter-spacing: 1.5px !important;
            color: #222 !important;
            margin-bottom: 8px !important;
            font-weight: 500 !important;
          }

          .trust-desc {
            font-size: 12px;
            color: #555;
            padding: 0;
            max-width: 100%;
            line-height: 1.5;
            font-style: normal; /* Editorial feel instead of italic */
          }
          
          .trust-link {
            font-size: 9.5px;
            letter-spacing: 1.5px;
            margin-top: 20px; /* Precise gap below description */
            color: #c1a68d;
            padding: 0;
            min-height: 44px;
            align-items: center;
          }
          
          .mobile-indicator-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
            padding: 0 20px;
          }
          .indicator-text {
            font-size: 10px;
            letter-spacing: 0.1em;
            color: #666;
            font-family: monospace;
          }
          .indicator-bar-container {
            flex: 0 0 100px;
            height: 1px;
            background-color: #e5e5e5;
            position: relative;
          }
          .indicator-bar-progress {
            position: absolute;
            top: 0;
            left: 0;
            height: 1px;
            background-color: #333;
            transition: width 0.3s ease, left 0.3s ease;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/home/TrustSection.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mobile-header-wrapper",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "mobile-section-heading",
                        children: "The Bespokewala Experience"
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 232,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mobile-section-sub",
                        children: "Thoughtfully crafted services designed around you."
                    }, void 0, false, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/TrustSection.tsx",
                lineNumber: 231,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "trust-grid",
                ref: scrollContainerRef,
                onScroll: handleScroll,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "trust-item",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "trust-card-num",
                                children: "01"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 239,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: titleStyle,
                                children: "Made to Order"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 240,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "trust-desc",
                                children: "Crafted especially for your order."
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 241,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "#couture-process",
                                "aria-label": "Discover the Couture Process",
                                className: "trust-link",
                                children: [
                                    "Discover the Process ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "arrow-icon",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/TrustSection.tsx",
                                        lineNumber: 243,
                                        columnNumber: 34
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 242,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 238,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "trust-item",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "trust-card-num",
                                children: "02"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 248,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: titleStyle,
                                children: "Custom Sizing"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 249,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "trust-desc",
                                children: "Designed to your measurements for a personalized fit."
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 250,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/size-guide",
                                "aria-label": "View Size Guide",
                                className: "trust-link",
                                children: [
                                    "View Size Guide ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "arrow-icon",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/TrustSection.tsx",
                                        lineNumber: 252,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 251,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "trust-item",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "trust-card-num",
                                children: "03"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 257,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: titleStyle,
                                children: "Personal Styling"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "trust-desc",
                                children: "Guidance for choosing your look."
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 259,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/contact",
                                "aria-label": "Book a Design Consultation",
                                className: "trust-link",
                                children: [
                                    "Book a Consultation ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "arrow-icon",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/TrustSection.tsx",
                                        lineNumber: 261,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 260,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "trust-item",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "trust-card-num",
                                children: "04"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: titleStyle,
                                children: "Shipping & Returns"
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "trust-desc",
                                children: "Clear information about delivery, exchanges and returns."
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 268,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/shipping",
                                "aria-label": "View Shipping and Return Policy",
                                className: "trust-link",
                                children: [
                                    "View Shipping & Returns ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "arrow-icon",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/TrustSection.tsx",
                                        lineNumber: 270,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TrustSection.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/home/TrustSection.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/home/TrustSection.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/TrustSection.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
_s(TrustSection, "146c30b9YlAc+za5546OdjUy3ZI=");
_c = TrustSection;
var _c;
__turbopack_context__.k.register(_c, "TrustSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/home/TestimonialsSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TestimonialsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const testimonials = [
    {
        id: 1,
        text: "The craftsmanship and attention to detail are unparalleled. My bespoke lehenga was absolutely flawless.",
        author: "Priya S.",
        location: "Mumbai, India",
        product: "Custom Bridal Lehenga",
        rating: 5
    },
    {
        id: 2,
        text: "Exceptional service from start to finish. The team understood exactly what I wanted for my wedding sherwani.",
        author: "Rahul M.",
        location: "London, UK",
        product: "Bespoke Sherwani Set",
        rating: 5
    },
    {
        id: 3,
        text: "Wearing Bespokewala makes you feel like royalty. The fabrics, the fit, the embroidery—pure luxury.",
        author: "Ayesha K.",
        location: "Dubai, UAE",
        product: "Emerald Zari Gown",
        rating: 5
    }
];
function TestimonialsSection() {
    _s();
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TestimonialsSection.useEffect": ()=>{
            const timer = setInterval({
                "TestimonialsSection.useEffect.timer": ()=>{
                    setActiveIndex({
                        "TestimonialsSection.useEffect.timer": (current)=>(current + 1) % testimonials.length
                    }["TestimonialsSection.useEffect.timer"]);
                }
            }["TestimonialsSection.useEffect.timer"], 5000);
            return ({
                "TestimonialsSection.useEffect": ()=>clearInterval(timer)
            })["TestimonialsSection.useEffect"];
        }
    }["TestimonialsSection.useEffect"], []);
    // Generate SVG stars
    const renderStars = (rating)=>{
        return Array.from({
            length: 5
        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "16",
                height: "16",
                viewBox: "0 0 24 24",
                fill: i < rating ? "#d2b48c" : "none",
                stroke: "#d2b48c",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                style: {
                    margin: '0 2px'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                    points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                }, void 0, false, {
                    fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this)
            }, i, false, {
                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "testimonials-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        .testimonials-section {
          background-color: #111;
          color: #fff;
          padding: 6rem 2rem;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }
        .testimonials-header {
          font-size: 0.85rem;
          letter-spacing: 0.3em;
          text-transform: uppercase;
          color: #d2b48c;
          margin-bottom: 3rem;
        }
        .testimonial-container {
          position: relative;
          width: 100%;
          max-width: 800px;
          min-height: 280px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .testimonial-slide {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 100%;
          opacity: 0;
          visibility: hidden;
          transition: opacity 0.8s ease, visibility 0.8s ease, transform 0.8s ease;
        }
        .testimonial-slide.active {
          opacity: 1;
          visibility: visible;
          transform: translate(-50%, -50%) scale(1);
        }
        .testimonial-slide.inactive {
          transform: translate(-50%, -50%) scale(0.95);
        }
        .testimonial-stars {
          margin-bottom: 1.5rem;
          display: flex;
          justify-content: center;
        }
        .testimonial-text {
          font-size: clamp(1.2rem, 3vw, 1.8rem);
          font-weight: 300;
          line-height: 1.6;
          font-style: italic;
          margin-bottom: 2rem;
          color: #f8f8f8;
        }
        .testimonial-author {
          font-size: 0.9rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          font-weight: 500;
          color: #d2b48c;
        }
        .testimonial-meta {
          font-size: 0.75rem;
          color: #888;
          margin-top: 0.75rem;
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
          letter-spacing: 0.05em;
        }
        .testimonial-product {
          color: #aaa;
          font-style: italic;
        }
        .testimonial-indicators {
          display: flex;
          gap: 12px;
          margin-top: 2rem;
        }
        .indicator-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background-color: #444;
          cursor: pointer;
          transition: background-color 0.3s ease;
          border: none;
          padding: 0;
        }
        .indicator-dot.active {
          background-color: #d2b48c;
        }
        
        @media (max-width: 768px) {
          .testimonials-section {
            padding: 3rem 1.25rem;
          }
          .testimonial-container {
            min-height: 320px;
          }
          .testimonial-text {
            font-size: 1.25rem;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "testimonials-header",
                children: "Client Testimonials"
            }, void 0, false, {
                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "testimonial-container",
                children: testimonials.map((t, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `testimonial-slide ${index === activeIndex ? 'active' : 'inactive'}`,
                        "aria-hidden": index !== activeIndex,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-stars",
                                children: renderStars(t.rating)
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                lineNumber: 173,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-text",
                                children: [
                                    '"',
                                    t.text,
                                    '"'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-author",
                                children: t.author
                            }, void 0, false, {
                                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                lineNumber: 177,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-meta",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "testimonial-location",
                                        children: t.location
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                        lineNumber: 179,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "testimonial-product",
                                        children: [
                                            "Purchased: ",
                                            t.product
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                        lineNumber: 180,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                                lineNumber: 178,
                                columnNumber: 13
                            }, this)
                        ]
                    }, t.id, true, {
                        fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                        lineNumber: 168,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "testimonial-indicators",
                children: testimonials.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `indicator-dot ${index === activeIndex ? 'active' : ''}`,
                        onClick: ()=>setActiveIndex(index),
                        "aria-label": `Go to testimonial ${index + 1}`
                    }, index, false, {
                        fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                        lineNumber: 188,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/home/TestimonialsSection.tsx",
                lineNumber: 186,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/home/TestimonialsSection.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(TestimonialsSection, "16En7kR7TbAJMjBrm+xutVNIc5Q=");
_c = TestimonialsSection;
var _c;
__turbopack_context__.k.register(_c, "TestimonialsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_0g8dp8z._.js.map