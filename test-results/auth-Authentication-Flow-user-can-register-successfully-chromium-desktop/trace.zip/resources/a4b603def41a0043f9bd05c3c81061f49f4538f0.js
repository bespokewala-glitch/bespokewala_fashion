(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1xaxipv._.css","static/chunks/node_modules_next_0gp0m15._.js","static/chunks/src_0stkq0-._.js"],
    source: "dynamic"
});
