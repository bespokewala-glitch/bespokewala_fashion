(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/chatbot/ChatPanel.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_1b5_o75._.js",
  "static/chunks/src_components_chatbot_ChatPanel_tsx_120qxwc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/chatbot/ChatPanel.tsx [app-client] (ecmascript)");
    });
});
}),
]);