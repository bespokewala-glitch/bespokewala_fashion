(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_chatbot_ChatPanel_tsx_0n7ej_i._.js","static/chunks/src_07lbpyt._.js","static/chunks/node_modules_1l48kgh._.js","static/chunks/src_app_chatbot_1dnbqn8.css"],
    source: "dynamic"
});
