(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/context/CartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const CartProvider = ({ children })=>{
    _s();
    const [cart, setCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMiniCartOpen, setIsMiniCartOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isAuthenticated, setIsAuthenticated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openMiniCart = ()=>setIsMiniCartOpen(true);
    const closeMiniCart = ()=>setIsMiniCartOpen(false);
    // Sync cart to backend
    const syncCartToBackend = async (currentCart)=>{
        if (!isAuthenticated) return;
        try {
            await fetch('/api/cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    items: currentCart
                })
            });
        } catch (e) {
            console.error('Failed to sync cart to backend', e);
        }
    };
    // Load cart on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            const initCart = {
                "CartProvider.useEffect.initCart": async ()=>{
                    // Safely clear the old global cart
                    localStorage.removeItem('cart');
                    try {
                        const res = await fetch('/api/cart', {
                            cache: 'no-store'
                        });
                        if (res.ok) {
                            const data = await res.json();
                            setCart(data.items || []);
                            setIsAuthenticated(true);
                        } else {
                            // Guest user, 401 Unauthorized
                            setIsAuthenticated(false);
                            const savedCart = localStorage.getItem('bw_guest_cart');
                            if (savedCart) {
                                setCart(JSON.parse(savedCart));
                            }
                        }
                    } catch (e) {
                        console.error('Failed to fetch cart', e);
                    } finally{
                        setIsLoaded(true);
                    }
                }
            }["CartProvider.useEffect.initCart"];
            initCart();
        }
    }["CartProvider.useEffect"], []);
    // Save guest cart to local storage on change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            if (isLoaded && !isAuthenticated) {
                localStorage.setItem('bw_guest_cart', JSON.stringify(cart));
            }
        }
    }["CartProvider.useEffect"], [
        cart,
        isLoaded,
        isAuthenticated
    ]);
    const addToCart = (newItem)=>{
        const newCart = [
            ...cart
        ];
        const existingItemIndex = newCart.findIndex((item)=>item.id === newItem.id);
        if (existingItemIndex > -1) {
            newCart[existingItemIndex].quantity += newItem.quantity;
        } else {
            newCart.push(newItem);
        }
        setCart(newCart);
        if (isAuthenticated) syncCartToBackend(newCart);
    };
    const removeFromCart = (id)=>{
        const newCart = cart.filter((item)=>item.id !== id);
        setCart(newCart);
        if (isAuthenticated) syncCartToBackend(newCart);
    };
    const updateQuantity = (id, quantity)=>{
        if (quantity <= 0) {
            removeFromCart(id);
            return;
        }
        const newCart = cart.map((item)=>item.id === id ? {
                ...item,
                quantity
            } : item);
        setCart(newCart);
        if (isAuthenticated) syncCartToBackend(newCart);
    };
    const clearCart = ()=>{
        setCart([]);
        if (isAuthenticated) {
            fetch('/api/cart', {
                method: 'DELETE'
            }).catch(console.error);
        } else {
            localStorage.removeItem('bw_guest_cart');
        }
    };
    const resetCartState = ()=>{
        setCart([]);
        setIsAuthenticated(false);
    };
    const cartCount = cart.reduce((total, item)=>total + item.quantity, 0);
    const cartTotal = cart.reduce((total, item)=>total + item.price * item.quantity, 0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: {
            cart,
            addToCart,
            removeFromCart,
            updateQuantity,
            clearCart,
            cartCount,
            cartTotal,
            isMiniCartOpen,
            openMiniCart,
            closeMiniCart,
            resetCartState
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/CartContext.tsx",
        lineNumber: 136,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CartProvider, "U3lGtM3BUpr0KfNKxxq0YpQR+Qg=");
_c = CartProvider;
const useCart = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
};
_s1(useCart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/WishlistContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WishlistProvider",
    ()=>WishlistProvider,
    "useWishlist",
    ()=>useWishlist
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const WishlistContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const WishlistProvider = ({ children })=>{
    _s();
    const [wishlist, setWishlist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Load from local storage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WishlistProvider.useEffect": ()=>{
            const savedWishlist = localStorage.getItem('wishlist');
            if (savedWishlist) {
                try {
                    setWishlist(JSON.parse(savedWishlist));
                } catch (e) {
                    console.error('Failed to parse wishlist from local storage', e);
                }
            }
            setIsLoaded(true);
        }
    }["WishlistProvider.useEffect"], []);
    // Save to local storage on change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WishlistProvider.useEffect": ()=>{
            if (isLoaded) {
                localStorage.setItem('wishlist', JSON.stringify(wishlist));
            }
        }
    }["WishlistProvider.useEffect"], [
        wishlist,
        isLoaded
    ]);
    const addToWishlist = (newItem)=>{
        setWishlist((prev)=>{
            const exists = prev.some((item)=>item.slug === newItem.slug);
            if (exists) return prev;
            return [
                ...prev,
                newItem
            ];
        });
    };
    const removeFromWishlist = (slug)=>{
        setWishlist((prev)=>prev.filter((item)=>item.slug !== slug));
    };
    const clearWishlist = ()=>{
        setWishlist([]);
    };
    const isInWishlist = (slug)=>{
        return wishlist.some((item)=>item.slug === slug);
    };
    const wishlistCount = wishlist.length;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WishlistContext.Provider, {
        value: {
            wishlist,
            addToWishlist,
            removeFromWishlist,
            clearWishlist,
            isInWishlist,
            wishlistCount
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/WishlistContext.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(WishlistProvider, "/penTDyBdJVmkjdIAkD99dpPJB4=");
_c = WishlistProvider;
const useWishlist = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(WishlistContext);
    if (context === undefined) {
        throw new Error('useWishlist must be used within a WishlistProvider');
    }
    return context;
};
_s1(useWishlist, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "WishlistProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/config/currencyConfig.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BASE_CURRENCY",
    ()=>BASE_CURRENCY,
    "COUNTRY_TO_CURRENCY",
    ()=>COUNTRY_TO_CURRENCY,
    "DEFAULT_FALLBACK_CURRENCY",
    ()=>DEFAULT_FALLBACK_CURRENCY,
    "SUPPORTED_CURRENCIES",
    ()=>SUPPORTED_CURRENCIES
]);
const BASE_CURRENCY = 'INR';
const SUPPORTED_CURRENCIES = {
    INR: {
        code: 'INR',
        symbol: '₹',
        name: 'Indian Rupee',
        locale: 'en-IN',
        decimals: 0
    }
};
const COUNTRY_TO_CURRENCY = {
    IN: 'INR'
};
const DEFAULT_FALLBACK_CURRENCY = 'INR';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/CurrencyContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CurrencyProvider",
    ()=>CurrencyProvider,
    "useCurrency",
    ()=>useCurrency
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$currencyConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/currencyConfig.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const CurrencyContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const CurrencyProvider = ({ children })=>{
    _s();
    // Hardcoded to INR
    const [currency] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$currencyConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CURRENCY"]);
    const [rates] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        INR: 1
    });
    const [isLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleSetCurrency = (code)=>{
    // No-op. Site is strictly INR.
    };
    const currentDetail = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$currencyConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUPPORTED_CURRENCIES"][currency] || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$currencyConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUPPORTED_CURRENCIES"][__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$currencyConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CURRENCY"]];
    const convertPrice = (priceInINR)=>{
        const numericPrice = typeof priceInINR === 'number' ? priceInINR : parseFloat(priceInINR) || 0;
        return {
            amount: numericPrice,
            symbol: currentDetail.symbol,
            currency: currentDetail.code
        };
    };
    const formatPrice = (priceInINR)=>{
        const { amount } = convertPrice(priceInINR);
        return `₹${Math.round(amount).toLocaleString('en-IN')}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CurrencyContext.Provider, {
        value: {
            currency,
            currencyDetail: currentDetail,
            rates,
            isLoading,
            setCurrency: handleSetCurrency,
            formatPrice,
            convertPrice
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/CurrencyContext.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CurrencyProvider, "w/5Uaf4qRvucz2lrSGPbFkHRkfI=");
_c = CurrencyProvider;
const useCurrency = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CurrencyContext);
    if (!context) {
        throw new Error('useCurrency must be used within a CurrencyProvider');
    }
    return context;
};
_s1(useCurrency, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CurrencyProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MetaPixel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MetaPixel,
    "event",
    ()=>event,
    "pageview",
    ()=>pageview
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const FB_PIXEL_ID = ("TURBOPACK compile-time value", "1618241526591086");
const pageview = ()=>{
    if (("TURBOPACK compile-time value", "object") !== "undefined" && window.fbq) {
        window.fbq("track", "PageView");
    }
};
const event = (name, options = {}, eventIdData)=>{
    if (("TURBOPACK compile-time value", "object") !== "undefined" && window.fbq) {
        if (eventIdData) {
            window.fbq("track", name, options, eventIdData);
        } else {
            window.fbq("track", name, options);
        }
    }
};
function MetaPixelInner() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MetaPixelInner.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            // This ensures PageView fires on route changes
            if (loaded) {
                pageview();
            }
        }
    }["MetaPixelInner.useEffect"], [
        pathname,
        searchParams,
        loaded
    ]);
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "fb-pixel",
            strategy: "afterInteractive",
            dangerouslySetInnerHTML: {
                __html: `
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '${FB_PIXEL_ID}');
            fbq('track', 'PageView');
          `
            },
            onLoad: ()=>setLoaded(true)
        }, void 0, false, {
            fileName: "[project]/src/components/MetaPixel.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(MetaPixelInner, "Yn1gOCuMcfxZR4r7R8GZUehN4dU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = MetaPixelInner;
function MetaPixel() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: null,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MetaPixelInner, {}, void 0, false, {
            fileName: "[project]/src/components/MetaPixel.tsx",
            lineNumber: 80,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/MetaPixel.tsx",
        lineNumber: 79,
        columnNumber: 5
    }, this);
}
_c1 = MetaPixel;
var _c, _c1;
__turbopack_context__.k.register(_c, "MetaPixelInner");
__turbopack_context__.k.register(_c1, "MetaPixel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/gtag.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * GA4 / Google Analytics 4 helper module
 *
 * Pattern mirrors the existing MetaPixel.tsx implementation.
 * All events are no-ops when NEXT_PUBLIC_GA_ID is not set or when
 * called server-side, so there are no hydration concerns.
 *
 * Duplicate-purchase guard: trackPurchase checks sessionStorage key
 * `ga4_purchased_{orderId}` before firing to prevent double-firing on
 * re-renders, back-navigation, or React StrictMode double-invoke.
 */ __turbopack_context__.s([
    "GA_MEASUREMENT_ID",
    ()=>GA_MEASUREMENT_ID,
    "event",
    ()=>event,
    "pageview",
    ()=>pageview,
    "trackAddPaymentInfo",
    ()=>trackAddPaymentInfo,
    "trackAddShippingInfo",
    ()=>trackAddShippingInfo,
    "trackAddToCart",
    ()=>trackAddToCart,
    "trackAddToWishlist",
    ()=>trackAddToWishlist,
    "trackBeginCheckout",
    ()=>trackBeginCheckout,
    "trackCategorySelection",
    ()=>trackCategorySelection,
    "trackChatWithStylist",
    ()=>trackChatWithStylist,
    "trackProductFilter",
    ()=>trackProductFilter,
    "trackProductSort",
    ()=>trackProductSort,
    "trackPurchase",
    ()=>trackPurchase,
    "trackRemoveFromCart",
    ()=>trackRemoveFromCart,
    "trackSearch",
    ()=>trackSearch,
    "trackSizeSelection",
    ()=>trackSizeSelection,
    "trackViewItem",
    ()=>trackViewItem,
    "trackVirtualTryOn",
    ()=>trackVirtualTryOn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const GA_MEASUREMENT_ID = ("TURBOPACK compile-time value", "G-R0KX9D5YSS");
const pageview = (url)=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.gtag || !GA_MEASUREMENT_ID) return;
    window.gtag('config', GA_MEASUREMENT_ID, {
        page_path: url
    });
};
const event = (action, params = {})=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.gtag || !GA_MEASUREMENT_ID) return;
    window.gtag('event', action, params);
};
const trackViewItem = (product)=>{
    event('view_item', {
        currency: 'INR',
        value: product.price ?? 0,
        items: [
            {
                item_id: product.slug,
                item_name: product.name,
                item_category: product.productType ?? '',
                item_category2: product.category ?? '',
                item_category3: product.subcategory ?? '',
                price: product.price ?? 0,
                quantity: 1
            }
        ]
    });
};
const trackAddToCart = (product)=>{
    event('add_to_cart', {
        currency: 'INR',
        value: product.price * product.quantity,
        items: [
            {
                item_id: product.slug,
                item_name: product.name,
                item_category: product.productType ?? '',
                item_category2: product.category ?? '',
                price: product.price,
                quantity: product.quantity
            }
        ]
    });
};
const trackRemoveFromCart = (item)=>{
    event('remove_from_cart', {
        currency: 'INR',
        value: item.price * item.quantity,
        items: [
            {
                item_id: item.productSlug,
                item_name: item.name,
                price: item.price,
                quantity: item.quantity
            }
        ]
    });
};
const trackAddToWishlist = (product)=>{
    event('add_to_wishlist', {
        currency: 'INR',
        value: product.price,
        items: [
            {
                item_id: product.slug,
                item_name: product.name,
                item_category: product.productType ?? '',
                item_category2: product.category ?? '',
                price: product.price,
                quantity: 1
            }
        ]
    });
};
const trackSearch = (searchTerm)=>{
    event('search', {
        search_term: searchTerm
    });
};
const trackBeginCheckout = (cartItems, total)=>{
    event('begin_checkout', {
        currency: 'INR',
        value: total,
        items: cartItems.map((item)=>({
                item_id: item.productSlug,
                item_name: item.name,
                price: item.price,
                quantity: item.quantity
            }))
    });
};
const trackAddShippingInfo = (cartItems, total)=>{
    event('add_shipping_info', {
        currency: 'INR',
        value: total,
        shipping_tier: 'Standard',
        items: cartItems.map((item)=>({
                item_id: item.productSlug,
                item_name: item.name,
                price: item.price,
                quantity: item.quantity
            }))
    });
};
const trackAddPaymentInfo = (cartItems, total, paymentType = 'Razorpay')=>{
    event('add_payment_info', {
        currency: 'INR',
        value: total,
        payment_type: paymentType,
        items: cartItems.map((item)=>({
                item_id: item.productSlug,
                item_name: item.name,
                price: item.price,
                quantity: item.quantity
            }))
    });
};
const trackPurchase = (order, orderId)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    // Duplicate guard — prevents re-firing on React StrictMode, re-renders,
    // back-navigation, and payment callback loops.
    const guardKey = `ga4_purchased_${orderId}`;
    if (sessionStorage.getItem(guardKey)) return;
    sessionStorage.setItem(guardKey, '1');
    event('purchase', {
        transaction_id: orderId,
        currency: 'INR',
        value: order.total,
        shipping: order.shipping ?? 0,
        tax: order.tax ?? 0,
        ...order.coupon ? {
            coupon: order.coupon
        } : {},
        items: order.items.map((item)=>({
                item_id: item.slug ?? item.productSlug ?? '',
                item_name: item.name,
                price: item.price,
                quantity: item.quantity
            }))
    });
};
const trackVirtualTryOn = (product)=>{
    event('virtual_try_on', {
        item_id: product.productId ?? '',
        item_name: product.productName ?? '',
        item_category: product.productCategory ?? '',
        value: product.productPrice ?? 0,
        currency: 'INR'
    });
};
const trackChatWithStylist = (product)=>{
    event('chat_with_stylist', {
        item_id: product.slug,
        item_name: product.name,
        item_category: product.productType ?? '',
        item_category2: product.category ?? ''
    });
};
const trackProductFilter = (filterKey, filterValue)=>{
    event('product_filter', {
        filter_type: filterKey,
        filter_value: filterValue
    });
};
const trackProductSort = (sortValue)=>{
    event('product_sort', {
        sort_by: sortValue
    });
};
const trackSizeSelection = (product, size)=>{
    event('size_selection', {
        item_id: product.slug,
        item_name: product.name,
        size
    });
};
const trackCategorySelection = (category, productType)=>{
    event('category_selection', {
        category,
        product_type: productType ?? ''
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GoogleAnalytics.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GoogleAnalytics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * GoogleAnalytics component
 *
 * Mirrors the existing MetaPixel.tsx architecture:
 * - Uses next/script with strategy="afterInteractive" for safe client-side loading
 * - Wrapped in <Suspense> to avoid hydration errors from useSearchParams
 * - Tracks SPA page_view on pathname/searchParams changes
 * - No-op when NEXT_PUBLIC_GA_ID is not set
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gtag.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function GoogleAnalyticsInner() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // Track whether the initial page_view has fired so we don't duplicate
    // the page_view that the gtag.js snippet fires automatically on load.
    const isInitialLoad = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GoogleAnalyticsInner.useEffect": ()=>{
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GA_MEASUREMENT_ID"]) return;
            // Skip the very first render — gtag.js fires page_view on load automatically
            if (isInitialLoad.current) {
                isInitialLoad.current = false;
                return;
            }
            // Fire page_view on client-side route changes (SPA navigation)
            const url = pathname + (searchParams.toString() ? `?${searchParams.toString()}` : "");
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageview"])(url);
        }
    }["GoogleAnalyticsInner.useEffect"], [
        pathname,
        searchParams
    ]);
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GA_MEASUREMENT_ID"]) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "google-analytics-script",
                strategy: "afterInteractive",
                src: `https://www.googletagmanager.com/gtag/js?id=${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GA_MEASUREMENT_ID"]}`
            }, void 0, false, {
                fileName: "[project]/src/components/GoogleAnalytics.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "google-analytics-init",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            window.gtag = gtag;
            gtag('js', new Date());
            gtag('config', '${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gtag$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GA_MEASUREMENT_ID"]}', {
              page_path: window.location.pathname,
              send_page_view: true
            });
          `
                }
            }, void 0, false, {
                fileName: "[project]/src/components/GoogleAnalytics.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(GoogleAnalyticsInner, "CqpKtkCaTBG57EAkJ9lX5w0tjEE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = GoogleAnalyticsInner;
function GoogleAnalytics() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: null,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GoogleAnalyticsInner, {}, void 0, false, {
            fileName: "[project]/src/components/GoogleAnalytics.tsx",
            lineNumber: 73,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/GoogleAnalytics.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_c1 = GoogleAnalytics;
var _c, _c1;
__turbopack_context__.k.register(_c, "GoogleAnalyticsInner");
__turbopack_context__.k.register(_c1, "GoogleAnalytics");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0stkq0-._.js.map